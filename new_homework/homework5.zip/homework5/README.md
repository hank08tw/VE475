problem 4 programming readme file.
This is a complete implementation of encryption and decryption of RSA including generate function.
Use g++ -o main main.cpp to generate executable file main, then ./main to run it.

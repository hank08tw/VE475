I implement Pollard’s Rho Algorithm in main.cpp
Use $g++ -o main main.cpp to compile and assemble the program, use $./main to run the program.
Enter the integer you want to be factorized, and you can see the result.